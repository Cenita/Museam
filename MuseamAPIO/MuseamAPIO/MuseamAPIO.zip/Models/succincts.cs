﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MuseamAPIO.Models
{
    public class succincts
    {
        public int id { get; set; }
        public string classname { get; set; }
        public string img { get; set; }
    }
}
