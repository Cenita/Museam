﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MuseamAPIO.Models
{
    public class banner
    {
        public int id { get; set; }
        public string name { get; set; }
        public string img { get; set; }
    }
}
