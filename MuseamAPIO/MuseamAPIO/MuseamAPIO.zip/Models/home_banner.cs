﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MuseamAPIO.Models
{
    public class home_banner
    {
        public int id { get; set; }
        public string banner { get; set; }
        public string note { get; set; }
        public string url { get; set; }
    }
}
